/*
 * Icon image from: http://www.fruitycuties.com/featured-fruit-jokes/broccoli-kawaii-veg-joke.htm
 */
package com.tracking.trackingapp;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	//Declared two buttons
	Button enterWeatherButton;
	Button enterTrackingButton;
	TextView theAppName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		theAppName = (TextView) findViewById(R.id.appNameReal);
		Typeface face = Typeface.createFromAsset(getAssets(), 
				"fonts/Shojumaru-Regular.ttf");
		theAppName.setTypeface(face);
		
		//Initializing them to match the buttons in the main xml file
		enterWeatherButton = (Button) findViewById(R.id.weatherButton);
		enterTrackingButton = (Button) findViewById(R.id.trackingButton);
		
		//Listeners
		enterWeatherButton.setOnClickListener(enterWeatherButtonListener);
		enterTrackingButton.setOnClickListener(enterTrackingButtonListener);
	}

	//Creating the listener when the weather button is pressed to go to the weather page
	public OnClickListener enterWeatherButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			//Connecting this intent to another one
			Intent intent = new Intent(MainActivity.this, WeatherMain.class);
			startActivity(intent);
			
		}
	};
	
	//Creating the listener when the tracking button is pressed to go to the tracking page
	public OnClickListener enterTrackingButtonListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			Intent intent = new Intent(MainActivity.this, TrackingMain.class);
			startActivity(intent);
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;
import java.util.Scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginCreate extends Activity{
	
	Button startTrackingButton;
	public final static String LC_SYMBOL_USER = "com.broccoli.logincreate.user";
	public final static String LC_SYMBOL_PASS = "com.broccoli.logincreate.password";
	public final static String LC_SYMBOL_ACCE = "com.broccoli.logincreate.acce";
	public String LC_SYMBOL_JSON = "com.broccoli.logincreate.json";

	EditText userName;
	EditText passwordCreate;
	EditText passwordCheck;
	String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/insert/";	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_user);
		
//		//Initializing them to match the buttons in the main xml file
		startTrackingButton = (Button) findViewById(R.id.startTrackingButton);

		userName = (EditText) findViewById(R.id.usernameEditText);
		passwordCreate = (EditText) findViewById(R.id.passwordCreate);
		passwordCheck = (EditText) findViewById(R.id.passwordCheck);
		
		startTrackingButton.setOnClickListener(startTrackingButtonListener);

	}
	private class MyAsyncTask extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "54";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;
				
				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			}
			finally {
			}

			return result;
		}
	
	}
	
	public OnClickListener startTrackingButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			
			if(passwordCheck.getText().toString().equals(passwordCreate.getText().toString())){
				
				Random r = new Random();
				String code = "";
				for(int i = 0; i<6; i++){
					code = code + r.nextInt(10);
				}
				//Log.i("test","in LoginCreate. code = " + code);
				String user = userName.getText().toString();
				String pass = passwordCreate.getText().toString();

				
				platoURL = platoURL + user + "/" + pass + 
						"/null/null/null/2014-01-01/2/" + code;
				
				new MyAsyncTask().execute(platoURL);
				
				Log.i("test","in onClick. After myasync task");
				//Connecting this intent to another one
				Intent intent = new Intent(LoginCreate.this, ActivityMaster.class);
				Bundle extras = new Bundle();
	
	            extras.putString(LC_SYMBOL_USER, user);
	            extras.putString(LC_SYMBOL_PASS, pass);
	            extras.putString(LC_SYMBOL_ACCE, code);
	            intent.putExtras(extras);
				
				
				
				Log.i("test","in onClick. After intent task");
				startActivity(intent);

			}
			else {

				// Create an alert dialog box
				AlertDialog.Builder builder = new AlertDialog.Builder(
						LoginCreate.this);

				// Set alert title
				builder.setTitle(R.string.invalid_password);

				// Set the value for the positive reaction from the user
				// You can also set a listener to call when it is pressed
				builder.setPositiveButton(R.string.ok, null);

				// The message
				builder.setMessage(R.string.bad_password);

				// Create the alert dialog and display it
				AlertDialog theAlertDialog = builder.create();
				theAlertDialog.show();

			}

			
		}
	};
	
	
	
	
	
	
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

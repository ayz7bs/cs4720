package com.tracking.trackingapp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

//import java.util.ArrayList;

public class ActivityTrackingList extends Activity {

	ListView friendList;
	ArrayList<String> values;
	ArrayAdapter<String> adapter;

	EditText ACEditText;
	Button ACButton;
	String herokuURL = "http://broccoliwebservice.herokuapp.com/";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tracking_list);// for people to sign in

		// initialized the new user button
		ACButton = (Button) findViewById(R.id.ACButton);
		ACEditText = (EditText) findViewById(R.id.ACEditText);

		ACButton.setOnClickListener(friendListener);

	}

	public String UtS(String str) {
		String result = "";

		String temp[] = str.split("_");
		for (int j = 0; j < temp.length; j++) {
			result += temp[j] + " ";
		}
		result.trim();

		return result;

	}

	public OnClickListener friendListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			Log.i("test", "ATL. Before initView in onClick");
			initView();

		}
	};

	public static String getJSONfromURL(String url) {

		// initialize
		InputStream is = null;
		String result = "";

		// http post
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(url);
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();

		} catch (Exception e) {
			Log.i("test", "http connection error");
		}

		// convert response to string
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.i("test", "ATL. getJSONfromURL. result = " + result);
		} catch (Exception e) {
			Log.e("test", "Error converting result " + e.toString());
		}

		return result;
	}

	private class GetFriends extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
		}

		@Override
		protected String doInBackground(String... params) {
			String url = params[0];
			ArrayList<String> lcs = new ArrayList<String>();
			try {

				// webJSON is a string
				String webJSON = getJSONfromURL(url);

				JsonParser parser = new JsonParser();
				JsonArray Jarray = parser.parse(webJSON).getAsJsonArray();

				for (JsonElement obj : Jarray) {
					// turn JsonElement to a String
					String entry = obj.toString();

					if (!entry.contains("null")) {

						// split the entry string by randomness
						String regex = "[\\s\"};.,:!?()-]";
						String words[] = entry.split(regex);

						/*
						 * for(int i = 0; i < words.length; i++){ Log.i("test",
						 * "This is words at : " + i + ": " + words[i]); }
						 */

						// Date (year-month-day), Activity, Goal, Note, Duration

						String fEntry = "Date: " + words[22] + "-" + words[23]
								+ "-" + words[24].substring(0, 2) + ".  "
								+ "Activity: " + words[4] + ".  " + "Goal: "
								+ UtS(words[10]) + ".  " + "Notes: "
								+ UtS(words[16]) + ".  " + "Duration: "
								+ words[32];

						lcs.add(fEntry);
					}
				}

			} catch (Exception e) {
				Log.e("test", "Exception. JSONPARSE:" + e.toString());
			}
			values.clear();
			values.addAll(lcs);
			return "done!";
		}

		@Override
		protected void onProgressUpdate(Integer... ints) {

		}

		@Override
		protected void onPostExecute(String result) {
			Log.i("test", "ATL. onPostExecute");
			adapter.notifyDataSetChanged();
		}

	}

	public void initView() {
		Log.i("test", "ATL. inside initView from onClick");
		friendList = (ListView) findViewById(R.id.friendList);
		values = new ArrayList<String>();

		String ac = ACEditText.getText().toString();

		final String URLfinal = herokuURL + ac;

		adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, values);

		friendList.setAdapter(adapter);

		new GetFriends().execute(URLfinal);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

package com.tracking.trackingapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.ExpandableListView.OnChildClickListener;

class Node {
	String activityName;
	ArrayList<String> info;

	public Node() {
		activityName = "";
		info = new ArrayList<String>();
	}//
}

public class ActivityMaster extends Activity {
	public final static String SYMBOL_USER = "com.broccoli.test.user";
	public final static String SYMBOL_PASS = "com.broccoli.test.password";
	public final static String SYMBOL_ACCE = "com.broccoli.test.access";
	public final static String AM_SYMBOL_USER = "com.broccoli.activitymaster.user";
	public final static String AM_SYMBOL_PASS = "com.broccoli.activitymaster.pass";
	public final static String AM_SYMBOL_ACCE = "com.broccoli.activitymaster.access";
	public final static String AM_SYMBOL_ACTI = "com.broccoli.activitymaster.activity";
	public final static String AM_SYMBOL_DATE = "com.broccoli.activitymaster.date";
	public final static String AM_SYMBOL_DURA = "com.broccoli.activitymaster.duration";
	public final static String AM_SYMBOL_NOTE = "com.broccoli.activitymaster.note";
	public final static String AM_SYMBOL_GOAL = "com.broccoli.activitymaster.goal";
	public final static String AM_SYMBOL_CHECK = "com.broccoli.activitymaster.check";

	Button insertNewActivityButton;
	Button addActivityEntryButton;
	Button activityTrackingListButton;// this is friend code
	Button editDeleteEntryButton;
	Button Home;
	public String u;
	public String p;
	public String acode;
	public String j;

	String activity;
	String date;
	String duration;
	String goal;
	String note;

	ExpandableListAdapter listAdapter;
	ExpandableListView expListView;
	List<String> listDataHeader;// will be activity names
	HashMap<String, List<String>> listDataChild;
	public String selectUserActivitiesjson;

	public String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/";

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_master);

		insertNewActivityButton = (Button) findViewById(R.id.insertNewActivityButtonXML);
		addActivityEntryButton = (Button) findViewById(R.id.addActivityEntryButtonXML);
		activityTrackingListButton = (Button) findViewById(R.id.AMactivityTrackingListButtonXML);
		editDeleteEntryButton = (Button) findViewById(R.id.editDeleteEntryButtonXML);
		Home = (Button) findViewById(R.id.Home);

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();

		String user = extras.getString(TrackingMainValidity.TMV_SYMBOL_USER);
		String pass = extras.getString(TrackingMainValidity.TMV_SYMBOL_PASS);
		String json = extras.getString(TrackingMainValidity.TMV_SYMBOL_JSON);

		String userLC = extras.getString(LoginCreate.LC_SYMBOL_USER);
		String passLC = extras.getString(LoginCreate.LC_SYMBOL_PASS);
		String acceLC = extras.getString(LoginCreate.LC_SYMBOL_ACCE);

		String userEDAd = extras.getString(EditDeleteActivity.EDA_SYMBOL_USER);
		String passEDAd = extras.getString(EditDeleteActivity.EDA_SYMBOL_PASS);
		String acceEDAd = extras.getString(EditDeleteActivity.EDA_SYMBOL_ACCE);
		String jsonEDAd = extras.getString(EditDeleteActivity.EDA_JSON);

		String userAAE = extras.getString(AddActivityEntry.AAE_SYMBOL_USER);
		String passAAE = extras.getString(AddActivityEntry.AAE_SYMBOL_PASS);
		String acceAAE = extras.getString(AddActivityEntry.AAE_SYMBOL_ACCE);
		String jsonAAE = extras.getString(AddActivityEntry.AAE_JSON);

		Log.i("test", "AM. user = " + user);
		Log.i("test", "AM. pass = " + pass);
		Log.i("test", "AM. userLC = " + userLC);
		Log.i("test", "AM. passLC = " + passLC);
		Log.i("test", "AM. acceLC = " + acceLC);
		Log.i("test", "AM. userEDAd = " + userEDAd);
		Log.i("test", "AM. passEDAd = " + passEDAd);
		Log.i("test", "AM. acceEDAd = " + acceEDAd);
		Log.i("test", "AM. jsonEDAd = " + jsonEDAd);
		Log.i("test", "AM. userAAE= " + userAAE);
		Log.i("test", "AM. passAAE = " + passAAE);
		Log.i("test", "AM. acceAAE = " + acceAAE);
		Log.i("test", "AM. jsonAAE = " + jsonAAE);

		Log.i("test", "AM. j= " + j);
		if (userEDAd != null) {
			u = userEDAd;
			p = passEDAd;
			j = jsonEDAd;

		} else if (userAAE != null) {
			u = userAAE;
			p = passAAE;
			j = jsonAAE;
		} else if (userLC != null) {
			u = userLC;
			p = passLC;

		} else {
			u = user;
			p = pass;
			j = json;
		}

		acode = "";
		selectUserActivitiesjson = j;// need if else statement

		Log.i("test", "acode.length==" + acode.length());
		platoURL = platoURL + u + "/" + p;
		Log.i("test", "platoURL = " + platoURL);
		if (acode.length() != 6) {
			new MyAsyncTask().execute(platoURL);
		} else {
			if (acceEDAd.length() == 6) {
				acode = acceEDAd;
			}
			if (acceLC.length() == 6) {
				acode = acceLC;
			}
		}
		Home.setOnClickListener(HomeButtonListener);

		insertNewActivityButton
				.setOnClickListener(insertNewActivityButtonListener);
		addActivityEntryButton
				.setOnClickListener(addActivityEntryButtonListener);
		activityTrackingListButton
				.setOnClickListener(activityTrackingListButtonListener);
		editDeleteEntryButton.setOnClickListener(editDeleteEntryButtonListener);
		expListView = (ExpandableListView) findViewById(R.id.lvExp);

		Log.i("test", "AM. before prepareListData() call");

		expListView.setOnChildClickListener(childListener);
		prepareListData();
		listAdapter = new ExpandableListAdapter(this, listDataHeader,
				listDataChild);

		// setting list adapter
		expListView.setAdapter(listAdapter);

	}
	public OnClickListener HomeButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			Intent intent = new Intent(ActivityMaster.this,
					MainActivity.class);
			startActivity(intent);

		}
	};

	public String UtS(String str) {
		String result = "";

		String temp[] = str.split("_");
		for (int j = 0; j < temp.length; j++) {
			result += temp[j] + " ";
		}
		result.trim();

		return result;

	}

	private ArrayList<Node> fromJson(String jsonString) {
		ArrayList<Node> result = new ArrayList<Node>();

		Log.i("test", "AM. fromJson method. jsonString: " + jsonString);
		String[] s = jsonString.split("\"");
		String compareName = "";// to compare activity names with
		for (int i = 0; i < s.length; i++) {
			// Log.i("test",i + ". s[i]: " + s[i]);
			if (s[i].equals("activity")) {
				Node n = new Node();
				if (!(s[i + 2].equals(compareName))
						&& !(s[i + 2].equals("null"))) {
					Log.i("test", "s[i+2]:" + s[i + 2]);
					compareName = s[i + 2];// compareName == fly
					n.activityName = compareName;

					n.info.add("Date: " + s[i + 26] + ". ");

					n.info.add("User name: " + s[i - 14] + ". ");

					Log.i("test", "s[i+18]: " + s[i + 18]);
					String noteUtS = UtS(s[i + 18]);
					Log.i("test", "noteUtS: " + noteUtS);

					n.info.add("Note: " + noteUtS + ". ");

					String goalUtS = UtS(s[i + 10]);

					n.info.add("Goal: " + goalUtS + ". ");

					n.info.add("Duration: " + s[i + 34] + ". ");

					n.info.add("Your access code: " + s[i + 42] + ". ");

					result.add(n);
				} else if ((s[i + 2].equals(compareName))
						&& !(s[i + 2].equals("null"))) {
					Log.i("test", "s[i+2]:" + s[i + 2]);
					compareName = s[i + 2];// compareName == fly
					n.activityName = compareName;

					n.info.add("Date: " + s[i + 26] + ". ");

					n.info.add("User name: " + s[i - 14] + ". ");

					Log.i("test", "s[i+18]: " + s[i + 18]);
					String noteUtS = UtS(s[i + 18]);
					Log.i("test", "noteUtS: " + noteUtS);

					n.info.add("Note: " + noteUtS + ". ");

					String goalUtS = UtS(s[i + 10]);

					n.info.add("Goal: " + goalUtS + ". ");

					n.info.add("Duration: " + s[i + 34] + ". ");

					n.info.add("Your access code: " + s[i + 42] + ". ");

					result.add(n);
				}

			}
		}
		return result;

	}

	private void prepareListData() {
		listDataHeader = new ArrayList<String>();
		listDataChild = new HashMap<String, List<String>>();

		if (selectUserActivitiesjson == null) {// implies we're coming from
												// logincreate/new user
			listDataHeader.add("Add a new activity!");
			List<String> temp = new ArrayList<String>();
			temp.add("Add a new activity entry!");
			listDataChild.put(listDataHeader.get(0), temp);
		}

		else if (selectUserActivitiesjson != null) {

			ArrayList<Node> al = fromJson(selectUserActivitiesjson);
			Log.i("test", "AM. al size = " + al.size());

			String compareName = "";
			for (int i = 0; i < al.size(); i++) {
				if (!compareName.equals(al.get(i).activityName)) {
					compareName = al.get(i).activityName;
					listDataHeader.add(compareName);
				}
			}

			for (int i = 0; i < listDataHeader.size(); i++) {
				List<String> ldhInsert = new ArrayList<String>();

				for (int j = 0; j < al.size(); j++) {

					if (listDataHeader.get(i).equals(al.get(j).activityName)) {
						String toPutInldhInsert = "";
						for (int k = 0; k < al.get(j).info.size(); k++) {
							toPutInldhInsert += al.get(j).info.get(k) + " ";

						}
						ldhInsert.add(toPutInldhInsert);

					}

				}

				listDataChild.put(listDataHeader.get(i), ldhInsert);

			}

			Log.i("test", "listDataHeader size: " + listDataHeader.size());

		}
	}

	private class MyAsyncTask extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "54";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "AM. myasynctask response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection

				if (responseCode == HttpURLConnection.HTTP_OK) {
					Log.i("test", "AM. inside if responsecode==");
					Scanner test = new Scanner(url.openStream());
					String ugh = test.next();
					// Log.i("test","AM; ugh=" + ugh);

					String[] temp = ugh.split("\"");

					Log.i("test", "AM. before for loop");
					for (int i = 0; i < temp.length; i++) {

						if (temp[i].equals("accessCode")) {
							acode = temp[i + 2];
							Log.i("test", "in async. acode: " + acode);
							break;
						}
					}

				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			} finally {
			}

			return result;
		}

	}

	public OnChildClickListener childListener = new OnChildClickListener() {

		public boolean onChildClick(ExpandableListView parent, View v,
				int groupPosition, int childPosition, long id) {
			Toast.makeText(
					getApplicationContext(),
					listDataHeader.get(groupPosition)
							+ " : "
							+ listDataChild.get(
									listDataHeader.get(groupPosition)).get(
									childPosition), Toast.LENGTH_SHORT).show();
			String test = listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition);
			//Log.i("test","AM. onChildClicktest: " + test);
			String[] clickSplit = test.split(":");
			//for(int i = 0; i<clickSplit.length; i++){
			//	Log.i("test",i + " " + clickSplit[i]);
			//}
			// Date
			//1 2014-04-12. User name
			//2 test7. Note
			//3 yay . Goal
			//4 makeTwo . Duration
			//5 60. Your access code
			//6 092710
			
			// "\\."
			
			String[] temp = clickSplit[1].split("\\.");
			date = temp[0].trim();
			temp = clickSplit[3].split("\\.");
			note = temp[0].trim();
			temp = clickSplit[4].split("\\.");
			goal = temp[0].trim();
			temp = clickSplit[5].split("\\.");
			duration = temp[0].trim();
			activity = listDataHeader.get(groupPosition);
//			Log.i("test","date: " + date);
//			Log.i("test","note: " + note);
//			Log.i("test","goal: " + goal);
//			Log.i("test","duration: " + duration);
//			Log.i("test","activity: " + activity);
			
			return false;
		}

	};
	public OnClickListener activityTrackingListButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			Intent intent = new Intent(ActivityMaster.this,
					ActivityTrackingList.class);
			startActivity(intent);

		}
	};
	public OnClickListener editDeleteEntryButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// Connecting this intent to another one
			Log.i("test", "AM. inside editDeleteEntryButtonListener");
			Intent intent = new Intent(ActivityMaster.this,
					EditDeleteActivity.class);
			
			Bundle bExtras = new Bundle();
			bExtras.putString(AM_SYMBOL_USER, u);
			bExtras.putString(AM_SYMBOL_PASS, p);
			bExtras.putString(AM_SYMBOL_ACTI, activity);
			bExtras.putString(AM_SYMBOL_DATE, date);

			bExtras.putString(AM_SYMBOL_DURA, duration);
			bExtras.putString(AM_SYMBOL_GOAL, goal);
			bExtras.putString(AM_SYMBOL_NOTE, note);
			bExtras.putString(AM_SYMBOL_ACCE, acode);

			intent.putExtras(bExtras);
			startActivity(intent);
			Log.i("test", "AM. eDEBL. after start activity");

		}
	};
	public OnClickListener addActivityEntryButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			Intent intent = new Intent(ActivityMaster.this,
					AddActivityEntry.class);
			Bundle extras = new Bundle();
			if(activity!=null){

			extras.putString(AM_SYMBOL_USER, u);
			extras.putString(AM_SYMBOL_PASS, p);
			extras.putString(AM_SYMBOL_ACCE, acode);
			extras.putString(AM_SYMBOL_ACTI, activity);
			extras.putString(AM_SYMBOL_GOAL, goal);
			extras.putString(AM_SYMBOL_CHECK, "0");

			intent.putExtras(extras);
			Log.i("test", "AM. before add entry startActivity");
			startActivity(intent);
			}
			else {

				// Create an alert dialog box
				AlertDialog.Builder builder = new AlertDialog.Builder(
						ActivityMaster.this);

				// Set alert title
				builder.setTitle("Incorrect");

				// Set the value for the positive reaction from the user
				// You can also set a listener to call when it is pressed
				builder.setPositiveButton(R.string.ok, null);

				// The message
				builder.setMessage("No activity entry selected");

				// Create the alert dialog and display it
				AlertDialog theAlertDialog = builder.create();
				theAlertDialog.show();

			}

		}
	};
	public OnClickListener insertNewActivityButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			Intent intent = new Intent(ActivityMaster.this,
					InsertNewActivity.class);
			Bundle extras = new Bundle();
			extras.putString(AM_SYMBOL_USER, u);
			extras.putString(AM_SYMBOL_PASS, p);
			extras.putString(AM_SYMBOL_ACCE, acode);
			intent.putExtras(extras);
			startActivity(intent);

		}
	};

	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

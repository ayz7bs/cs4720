package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EditDeleteActivity extends Activity {
	Button EditButton;
	Button DeleteButton;
	Button backButton1;

	// added these two 4-10 for edit field and value for php

	EditText editValue;
	TextView EDactivityTextView;
	Spinner spinner1;

	public final static String EDA_SYMBOL_USER = "com.broccoli.editdeleteactivity.user";
	public final static String EDA_SYMBOL_PASS = "com.broccoli.editdeleteactivity.pass";
	public final static String EDA_SYMBOL_ACCE = "com.broccoli.editdeleteactivity.access";
	public final static String EDA_SYMBOL_ACTI = "com.broccoli.editdeleteactivity.activity";
	public final static String EDA_SYMBOL_DATE = "com.broccoli.editdeleteactivity.date";
	public final static String EDA_SYMBOL_DURA = "com.broccoli.editdeleteactivity.duration";
	public final static String EDA_SYMBOL_NOTE = "com.broccoli.editdeleteactivity.note";
	public final static String EDA_SYMBOL_GOAL = "com.broccoli.editdeleteactivity.goal";
	public final static String EDA_JSON = "com.broccoli.editdeleteactivity.json";

	public String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/";

	String u;
	String p;
	String acode;
	String a;
	String date;
	String dur;
	String n;
	String g;
	String json;

	// added these two 4-10 for edit field and value for php
	String ef;
	String ev;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit_delete_entry);

		EditButton = (Button) findViewById(R.id.editButton);
		DeleteButton = (Button) findViewById(R.id.deleteButton);
		backButton1 = (Button) findViewById(R.id.backbutton1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		EDactivityTextView = (TextView) findViewById(R.id.EDactivityTextView);
		
		

		// added these two 4-10 for edit field and value for php

		editValue = (EditText) findViewById(R.id.editValue);

		EditButton.setOnClickListener(EditButtonListener);
		DeleteButton.setOnClickListener(DeleteButtonListener);
		backButton1.setOnClickListener(BackButtonListener);

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();
		String user = extras.getString(ActivityMaster.AM_SYMBOL_USER);
		String pass = extras.getString(ActivityMaster.AM_SYMBOL_PASS);
		String code = extras.getString(ActivityMaster.AM_SYMBOL_ACCE);
		String acti = extras.getString(ActivityMaster.AM_SYMBOL_ACTI);
		String dat = extras.getString(ActivityMaster.AM_SYMBOL_DATE);
		String duration = extras.getString(ActivityMaster.AM_SYMBOL_DURA);
		String not = extras.getString(ActivityMaster.AM_SYMBOL_NOTE);
		String goa = extras.getString(ActivityMaster.AM_SYMBOL_GOAL);

		u = user;
		p = pass;
		a = acti;
		date = dat;
		dur = duration;
		n = not;
		g = goa;
		acode = code;

		EDactivityTextView.setText("Activity: " + a + ". Date: " + date
				+ ". Note: " + n + ". Goal: " + g + ". Duration: " + dur);
		
		Log.i("test", "inside EditDelete");
		Log.i("test", "user: " + u);
		Log.i("test", "password: " + p);
		Log.i("test", "activity: " + a);
		Log.i("test", "date: " + date);
		Log.i("test", "note: " + n);
		Log.i("test", "duration: " + dur);
		Log.i("test", "goal: " + g);
		Log.i("test", "accessCode: " + acode);
		//

		Log.i("test", "EDA");
		String getJSON = platoURL + u + "/" + p;
		new getJson().execute(getJSON);
	}

	public OnClickListener BackButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			// added these two 4-10 for edit field and value for php


			Intent intent = new Intent(EditDeleteActivity.this,
					ActivityMaster.class);
			Bundle extras = new Bundle();

			extras.putString(EDA_SYMBOL_USER, u);
			extras.putString(EDA_SYMBOL_PASS, p);
			extras.putString(EDA_SYMBOL_ACCE, acode);
			Log.i("test","EDA. json: " + json);
			extras.putString(EDA_JSON, json);

			intent.putExtras(extras);
			startActivity(intent);

		}
	};
	public String StU(String str){
		String result = "";
		String t=str.trim();
		String[]temp = t.split("\\s+");
		for(int i = 0; i<temp.length; i++){
			result+= temp[i] + "_";
		}
		result.trim();
		
		
		return result.substring(0,result.length()-1);
		
	}
	private class MyAsyncTask extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "54";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			} finally {
			}

			return result;
		}

	}

	private class getJson extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "54";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
					Scanner test = new Scanner(url.openStream());
					if (test.hasNext()) {
						json = test.next();
					}
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			} finally {
			}

			return result;
		}

	}

	public OnClickListener EditButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			// added these two 4-10 for edit field and value for php

			ev = editValue.getText().toString();
			Log.i("test","ev pre StU: " + ev);
			ev = StU(ev);
			Log.i("test","goal post StU: " + ev);
			ef = spinner1.getSelectedItem().toString();
			String editThing = platoURL + "update/" + u + "/" + p + "/" + a + "/"
					+ date + "/" + ef + "/" + ev;

			Log.i("test", "editThing: " + editThing);
			Log.i("test", "ev: " + ev);
			Log.i("test", "EDA. spinner: "
					+ spinner1.getSelectedItem().toString());
			new MyAsyncTask().execute(editThing);
			Toast.makeText(getApplicationContext(),
					"Entry updated", Toast.LENGTH_SHORT).show();
			String getJSON = platoURL + u + "/" + p;
			new getJson().execute(getJSON);
			
			editValue.setText("");
			
		}
	};

	public OnClickListener DeleteButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// added these two 4-10 for edit field and value for php
			String deleteThing = platoURL + "delete/" + u + "/" + p + "/" + a + "/"
					+ date;
			Log.i("test", "platoURL in delete " + deleteThing);

			new MyAsyncTask().execute(deleteThing);

			String getJSON = platoURL + u + "/" + p;
			Toast.makeText(getApplicationContext(),
					"Entry deleted", Toast.LENGTH_SHORT).show();
			new getJson().execute(getJSON);

		}
	};

}

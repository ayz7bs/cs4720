package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class InsertNewActivity extends Activity {
//	public final static String AM_SYMBOL_USER = "com.broccoli.activitymaster.user";
//	public final static String AM_SYMBOL_PASS = "com.broccoli.activitymaster.pass";
//	public final static String AM_SYMBOL_ACCE = "com.broccoli.activitymaster.acce";
	
	public final static String INA_SYMBOL_USER = "com.broccoli.insertnewactivity.user";
	public final static String INA_SYMBOL_PASS = "com.broccoli.insertnewactivity.pass";
	public final static String INA_SYMBOL_ACCE = "com.broccoli.insertnewactivity.acce";
	public final static String INA_SYMBOL_ACTI = "com.broccoli.insertnewactivity.acti";
	public final static String INA_SYMBOL_GOAL = "com.broccoli.insertnewactivity.goal";
	public final static String INA_SYMBOL_CHECK = "com.broccoli.insertnewactivity.check";
	public String u;
	public String p;
	public String acode;
	
	Button NACreateButton;
	EditText NAactivity;
	EditText NAgoal;
	String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/insert/";
	//String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/";

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.insert_new_activity);

		NACreateButton = (Button) findViewById(R.id.newActivityButton);
		NAactivity = (EditText) findViewById(R.id.NAactivity);
		NAgoal = (EditText) findViewById(R.id.NAgoal);

		NACreateButton.setOnClickListener(NACreateButtonListener);

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();
		
		
		//4-5 these 2 are the correct things
		u = extras.getString(ActivityMaster.AM_SYMBOL_USER);
		p = extras.getString(ActivityMaster.AM_SYMBOL_PASS);
		acode = extras.getString(ActivityMaster.AM_SYMBOL_ACCE);
		

		Log.i("test", "inside InsertNewActivity. u and p are: " + u + " " + p);


	}
	public String StU(String str){
		String result = "";
		String t=str.trim();
		String[]temp = t.split("\\s+");
		for(int i = 0; i<temp.length; i++){
			result+= temp[i] + "_";
		}
		result.trim();
		
		
		return result.substring(0,result.length()-1);
		
	}
	
	private class MyAsyncTask extends AsyncTask<String, String, String> {
		String friendResults;
		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;
				
				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			}
			finally {
			}

			return result;
		}
	
	}


	public OnClickListener NACreateButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			String activity = NAactivity.getText().toString();
			String goal = NAgoal.getText().toString();
			Log.i("test","goal pre StU: " + goal);
			goal = StU(goal);
			Log.i("test","goal post StU: " + goal);
			
			
			//replace space with underscore here
			
			platoURL = platoURL + u + "/" + p + "/" + activity + "/"
					+ goal + "/" + "a/01-01-2014/0/" + acode;
					

			Log.i("test", "in insertNewActivity. platoURL = " + platoURL);
			
			
			
			new MyAsyncTask().execute(platoURL);
			Log.i("test","in insertNewActivity. After asynctask");
			
			
			Intent intent = new Intent(InsertNewActivity.this,
					AddActivityEntry.class);
			Bundle extras = new Bundle();
					
			
			extras.putString(INA_SYMBOL_USER, u);
			extras.putString(INA_SYMBOL_PASS, p);
			extras.putString(INA_SYMBOL_ACCE, acode);
			extras.putString(INA_SYMBOL_ACTI, activity);
			extras.putString(INA_SYMBOL_GOAL, goal);
			extras.putString(INA_SYMBOL_CHECK, "11");
	        
			
			
			intent.putExtras(extras);
			
			startActivity(intent);

		}
	};

	
	
	
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

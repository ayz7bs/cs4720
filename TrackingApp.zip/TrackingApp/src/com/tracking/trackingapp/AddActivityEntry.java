package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddActivityEntry extends Activity {
	public final static String AAE_SYMBOL_USER = "com.broccoli.addactivityentry.user";
	public final static String AAE_SYMBOL_PASS = "com.broccoli.addactivityentry.pass";
	public final static String AAE_SYMBOL_ACCE = "com.broccoli.addactivityentry.acce";
	public final static String AAE_JSON = "com.broccoli.addactivityentry.json";

	Button AAEaddEntryButton;
	Button AAEbackbutton;
	EditText AAEnote;
	EditText AAEdate;
	EditText AAEduration;
	TextView activityTV;
	TextView goalTV;

	String u;
	String p;
	String acode;
	String acti;
	String goal;
	String check;
	String json;

	String platoURLu = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/update/";
	String platoURLi = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/insert/";
	String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/";

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_activity_entry);

		AAEaddEntryButton = (Button) findViewById(R.id.AAEaddEntryButtonXML);
		AAEbackbutton = (Button) findViewById(R.id.AAEbackbutton);
		AAEnote = (EditText) findViewById(R.id.AAEnoteXML);
		AAEdate = (EditText) findViewById(R.id.AAEdateXML);
		AAEduration = (EditText) findViewById(R.id.AAEdurationXML);
		activityTV = (TextView) findViewById(R.id.activityTV);
		goalTV = (TextView) findViewById(R.id.goalTV);

		AAEaddEntryButton.setOnClickListener(AAEaddEntryButtonListener);
		AAEbackbutton.setOnClickListener(back);

		// after finish getting 5 variables from create new activity
		// need to create if statement for getting 5 variables from activity
		// master
		
		Log.i("test", "in AAE");

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();

		// 4-5 these 2 are the correct things
		String INAuser = extras.getString(InsertNewActivity.INA_SYMBOL_USER);
		String INApass = extras.getString(InsertNewActivity.INA_SYMBOL_PASS);
		String INAacce = extras.getString(InsertNewActivity.INA_SYMBOL_ACCE);
		String INAacti = extras.getString(InsertNewActivity.INA_SYMBOL_ACTI);
		String INAgoal = extras.getString(InsertNewActivity.INA_SYMBOL_GOAL);
		String INAcheck = extras.getString(InsertNewActivity.INA_SYMBOL_CHECK);
		
		String AMuser = extras.getString(ActivityMaster.AM_SYMBOL_USER);
		String AMpass = extras.getString(ActivityMaster.AM_SYMBOL_PASS);
		String AMacce = extras.getString(ActivityMaster.AM_SYMBOL_ACCE);
		String AMacti = extras.getString(ActivityMaster.AM_SYMBOL_ACTI);
		String AMgoal = extras.getString(ActivityMaster.AM_SYMBOL_GOAL);
		String AMcheck = extras.getString(ActivityMaster.AM_SYMBOL_CHECK);
		Log.i("test", "INAuser = " + INAuser);
		Log.i("test", "INApass = " + INApass);
		Log.i("test", "INAacce = " + INAacce);
		Log.i("test", "INAacti = " + INAacti);
		Log.i("test", "INAgoal = " + INAgoal);
		Log.i("test", "INAcheck = " + INAcheck);
		
		Log.i("test", "AMuser = " + AMuser);
		Log.i("test", "AMpass = " + AMpass);
		Log.i("test", "AMacce = " + AMacce);
		Log.i("test", "AMacti = " + AMacti);
		Log.i("test", "AMgoal = " + AMgoal);
		Log.i("test", "AMcheck = " + AMcheck);
		
		
		
		if(INAcheck!= null){
		u = INAuser;
		p = INApass;
		acode = INAacce;
		acti = INAacti;
		goal = INAgoal;
		check = INAcheck;
		}
		else if( AMcheck != null){
			u = AMuser;
			p = AMpass;
			acode = AMacce;
			acti = AMacti;
			goal = AMgoal;
			check = AMcheck;
			
		}
		
		activityTV.setText(acti);
		goalTV.setText(goal);
		goal = StU(goal);

		Log.i("test", "u: " + u);
		
		String getJSON = platoURL + u + "/" + p;
		new getJson().execute(getJSON);
		
		
		Log.i("test", "inside AddActivityEntry. Check = " + check);

	}
	
	public OnClickListener back = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			Log.i("test", "AAE. in backbutton method");

			Intent intent = new Intent(AddActivityEntry.this,
					ActivityMaster.class);
			Bundle extras = new Bundle();
			extras.putString(AAE_SYMBOL_USER, u);
			extras.putString(AAE_SYMBOL_PASS, p);
			extras.putString(AAE_SYMBOL_ACCE, acode);
			extras.putString(AAE_JSON, json);
			
			intent.putExtras(extras);
			startActivity(intent);

		}
	};
	public String StU(String str){
		String result = "";
		String t=str.trim();
		String[]temp = t.split("\\s+");
		for(int i = 0; i<temp.length; i++){
			result+= temp[i] + "_";
		}
		result.trim();
		
		
		return result.substring(0,result.length()-1);
		
	}
	public OnClickListener AAEaddEntryButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			String note = AAEnote.getText().toString();
			Log.i("test","AAE. note pre StU: " + note);
			note = StU(note);
			Log.i("test","AAE. note post StU: " + note);
			String date = AAEdate.getText().toString();
			String dur = AAEduration.getText().toString();

			// THIS IS DEALING WITH UPDATING ONLY, NOT INSERT. STILL NEED TO DO
			// THAT
			if (check.length() == 2) {
				platoURLu = platoURLu + u + "/" + p + "/" + acti + "/" + goal
						+ "/" + note + "/" + date + "/" + dur;

				Log.i("test", "AAE updating. platoURLu = " + platoURLu);

				new MyAsyncTask().execute(platoURLu);

			}
			else{
				platoURLi = platoURLi + u + "/" + p + "/" + acti
				+ "/" + goal + "/" + note + "/" + date + "/" + dur + 
				"/" + acode;
			
				Log.i("test","AAE inserting. platoURLi = " + platoURLi);
			new MyAsyncTask().execute(platoURLi);
		}

			Log.i("test", "AAE. Before startActivity intent");
			platoURL = platoURL + u + "/" + p;
			new getJson().execute(platoURL);
			
			Toast.makeText(getApplicationContext(),
					"Entry added", Toast.LENGTH_SHORT).show();
			AAEnote.setText("");
			AAEdate.setText("");
			AAEduration.setText("");

		}
	};

	private class MyAsyncTask extends AsyncTask<String, String, String> {
		String friendResults;

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			} finally {
			}

			return result;
		}

	}

	private class getJson extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "54";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
					Scanner test = new Scanner(url.openStream());
					if (test.hasNext()) {
						json = test.next();
					}
				}
			} catch (MalformedURLException e) {
				Log.d("meh", "MalformedURLException", e);
			} catch (IOException e) {
				Log.d("meh", "IOException", e);
			} finally {
			}

			return result;
		}

	}


	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

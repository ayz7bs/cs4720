package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class WeatherMain extends Activity {

	Button enterDateButton;
	private EditText dateEditText;
	public TextView HighTempResult;
	public TextView LowTempResult;
	public TextView CurrentTempResult;
	private static final String TAG = "test2";
	// public final static String STOCK_SYMBOL = "com.web.weather.DATE";
	public final static String WEATHER_SYMBOL = "com.no.weather.DATE";
	public String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weather_main);

		enterDateButton = (Button) findViewById(R.id.XMLenterDateButton);
		dateEditText = (EditText) findViewById(R.id.XMLdateEditText);
		HighTempResult = (TextView) findViewById(R.id.HighTempResult);
		LowTempResult = (TextView) findViewById(R.id.LowTempResult);
		CurrentTempResult = (TextView) findViewById(R.id.CurrentTempResult);
		
		// listeners
		enterDateButton.setOnClickListener(enterDateButtonListener);

	}

	private class MyAsyncTask extends AsyncTask<String, String, String> {
		String weatherResult;

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;

				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				if (responseCode == HttpURLConnection.HTTP_OK) {

					Scanner test = new Scanner(url.openStream());
					// String[] weatherResult = { "test", "test2" };
					while (test.hasNext()) {
						weatherResult = test.nextLine();
					}
					result = weatherResult;
					Log.i("test", "WM. result = " + result);
				}
			} catch (MalformedURLException e) {
				Log.d(TAG, "MalformedURLException", e);
			} catch (IOException e) {
				Log.d(TAG, "IOException", e);
			} finally {
			}

			return result;
		}

		protected void onPostExecute(String result) {

			String cT = "";
			String hT = "";
			String lT = "";

			String[] aResult = result.split("\\{");

			Log.i("test", "WM. before for loop");
			for (int i = 0; i < aResult.length; i++) {
				String info = aResult[i];
				String[] infoParse = info.split("\"");
				Log.i("test",i + ". info: " + info);

				if (infoParse.length >= 19) {

					Log.i("test","WM. infoParse[15]: " + infoParse[15]);
					if (infoParse[15].equals("Daily Maximum Temperature")) {
						hT = infoParse[19] + "\u2109";

					} else if (infoParse[15]
							.equals("Daily Minimum Temperature")) {
						lT = infoParse[19]+ "\u2109";

					} else if (infoParse[15].equals("Temperature")) {
						cT = infoParse[19]+ "\u2109";
					}
				}
			}

			if (hT.length() == 0) {
				HighTempResult.setText("0");
			}
			if (lT.length() == 0) {
				LowTempResult.setText("0");
			}
			if (cT.length() == 0) {
				CurrentTempResult.setText("0");
			}
			Log.i("test", "WM. after for loop, before set texts");

			HighTempResult.setText(hT);
			LowTempResult.setText(lT);
			CurrentTempResult.setText(cT);
			Log.i("test", "WM. hT: " + hT + ". lT: " + lT + ". cT: " + cT);
		}

	}

	public OnClickListener enterDateButtonListener = new OnClickListener() {

		public void onClick(View theView) {

			// if statement to check whether there is input for dateEditText
			if (dateEditText.getText().length() > 0) {
				Log.i("test", "inside if statement for enterDateButtonListener");
				String date = dateEditText.getText().toString();
				Log.i("test", date);
				platoURL = platoURL + date;

				Log.i("test", "WM. Before async. platoURL = 	" + platoURL);
				new MyAsyncTask().execute(platoURL);

				dateEditText.setText("");

			}

			else {

				// Create an alert dialog box
				AlertDialog.Builder builder = new AlertDialog.Builder(
						WeatherMain.this);

				// Set alert title
				builder.setTitle(R.string.invalid_date);

				// Set the value for the positive reaction from the user
				// You can also set a listener to call when it is pressed
				builder.setPositiveButton(R.string.ok, null);

				// The message
				builder.setMessage(R.string.missing_date);

				// Create the alert dialog and display it
				AlertDialog theAlertDialog = builder.create();
				theAlertDialog.show();

			}

		}

	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

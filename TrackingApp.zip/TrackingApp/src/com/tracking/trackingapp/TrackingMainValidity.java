package com.tracking.trackingapp;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

public class TrackingMainValidity extends Activity{
	//TextView temp;
	private static final String TAG = "test";
	public final static String TMV_SYMBOL_USER = "com.broccoli.test.user";
	public final static String TMV_SYMBOL_PASS = "com.broccoli.test.password";
	public final static String TMV_SYMBOL_JSON = "com.broccoli.test.json";
	public String TMVUser;
	public String TMVPass;
	public String toPassJson;

	String platoURL = "http://plato.cs.virginia.edu/~cs4720s14broccoli/tracker/";
	
	
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		Bundle extras = intent.getExtras();
		
		
		
		//4-5 these 2 are the correct things
		String u = extras.getString(TrackingMain.TM_SYMBOL_USERNAME);
		String p = extras.getString(TrackingMain.TM_SYMBOL_PASSWORD);
		TMVUser = u;
		TMVPass = p;

		Log.i("test", "inside TrackingMainValidity and username = " + u);
		Log.i("test", "inside TrackingMainValidity and password = " + p);

		
		final String URLfinal = platoURL + u + "/" + p;
		//final String URLfinal = platoURL + "test7" + "/" + "test7";
		Log.i("test", "URLfinal: " + URLfinal);

		new MyAsyncTask().execute(URLfinal);

	}
	
	private class MyAsyncTask extends AsyncTask<String, String, String> {

		// String... arg0 is the same as String[] args
		protected String doInBackground(String... args) {
			String result = "test result";
			try {
				URL url = new URL(args[0]);
				URLConnection connection;
				connection = url.openConnection();
				HttpURLConnection httpConnection = (HttpURLConnection) connection;
				
				// Did we connect properly the the URL?
				int responseCode = httpConnection.getResponseCode();
				Log.i("test", "response code: " + responseCode);

				// Tests if responseCode == 200 Good Connection
				if (responseCode == HttpURLConnection.HTTP_OK) {
					
					Scanner test = new Scanner(url.openStream());

					if(test.hasNext()){
						toPassJson = test.next();
						Intent intent = new Intent(TrackingMainValidity.this,ActivityMaster.class);
						Bundle extras = new Bundle();
						
						//4-5 correct extras bundle passing
			            extras.putString(TMV_SYMBOL_USER, TMVUser);
			            extras.putString(TMV_SYMBOL_PASS, TMVPass);
						
						//below is how we get json stuff to parse in activity master
						extras.putString(TMV_SYMBOL_JSON, toPassJson);
						
			            //Log.i("test","TMV. json is: " + toPassJson);
			            Log.i("test","In TMV. TMVUser is: " + TMVUser);
			            Log.i("test","In TMV. TMVPass is: " + TMVPass);
			            intent.putExtras(extras);
						startActivity(intent);
					}
					else{
						Log.i("test","test does not has Next");
						Intent intent = new Intent(TrackingMainValidity.this, TrackingMain.class);
			            Log.i("test","right before startActivity in TMV");
			            startActivity(intent);
			            Log.i("test","After startActivity in TMV");
					}

				}
			} catch (MalformedURLException e) {
				Log.d(TAG, "MalformedURLException", e);
			} catch (IOException e) {
				Log.d(TAG, "IOException", e);
			}
			finally {
			}

			return result;
		}
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

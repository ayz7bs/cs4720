package com.tracking.trackingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class TrackingMain extends Activity {

	Button newUserButton;
	EditText userNameWelcomeEditText;// added "Welcome" to distinguish tween
										// LoginCreate
	EditText passwordWelcomeEditText;// added "welcome" to distinguish tween
										// LoginCreate
	Button go;
	
	public final static String TM_SYMBOL_USERNAME = "com.broccoli.trackingmain.user";
	public final static String TM_SYMBOL_PASSWORD = "com.broccoli.trackingmain.pass";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tracking_main);// for people to sign in

		newUserButton = (Button) findViewById(R.id.newUserButton);
		go = (Button) findViewById(R.id.go);
		userNameWelcomeEditText = (EditText) findViewById(R.id.userNameWelcomeEditText);
		passwordWelcomeEditText = (EditText) findViewById(R.id.passwordWelcomeEditText);
		newUserButton.setOnClickListener(createNewUser);
		go.setOnClickListener(goListener);

	}

	public OnClickListener createNewUser = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			Intent intent = new Intent(TrackingMain.this, LoginCreate.class);
			startActivity(intent);

		}
	};

	public OnClickListener goListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {

			Log.i("test", "goListener in TrackingMain.java");
			String username = userNameWelcomeEditText.getText().toString();
			Log.i("test", username);
			String password = passwordWelcomeEditText.getText().toString();
			Log.i("test", password);

			Intent intent = new Intent(TrackingMain.this, TrackingMainValidity.class);
			Bundle extras = new Bundle();
            extras.putString(TM_SYMBOL_USERNAME, username);
            extras.putString(TM_SYMBOL_PASSWORD, password);
            intent.putExtras(extras);
            
            Log.i("test","right before intent.putExtra in MainActivity");
            startActivity(intent);
            Log.i("test","After startActivity");
			
			
		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

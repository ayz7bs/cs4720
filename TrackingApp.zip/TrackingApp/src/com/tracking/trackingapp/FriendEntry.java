package com.tracking.trackingapp;

public class FriendEntry {

	public String activity;
	public String note;
	public String goal;
	public String date;

	public int duration;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "FriendEntry [activity=" + activity + ", note=" + note
				+ ", goal=" + goal + ", date=" + date
				+ ", duration=" + duration + "]";
	}
}
